<?php

/*
  Template name: Api Cart
 */

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['stProduct'])) {
        
        if (isset($_POST['stVariation'])) {
            WC()->cart->add_to_cart($_POST['stProduct'], $_POST['stQuantity'], $_POST['stVariation']);
            $msg = 'Cart updated';
            $status = 'success';
        } else {
            if(!WC()->cart->add_to_cart($_POST['stProduct'], $_POST['stQuantity']))
        
            WC()->cart->add_to_cart($_POST['stProduct'], $_POST['stQuantity']);
        }
       
    }
    $response_arr = array('message' => $msg, 'status' => $status);
        echo json_encode($response_arr);
}

?>
